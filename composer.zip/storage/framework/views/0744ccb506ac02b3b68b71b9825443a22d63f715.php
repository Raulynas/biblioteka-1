
<?php $__env->startSection('content'); ?>

<div class="section container">
    <div class="row">
        <div class="col s12 l5 offset-l3">
            
            <form method="post" action="">
                <?php echo csrf_field(); ?>
                <div class="input-field">
                    <input type="text" name="name" id="name" required>
                    <label for="name">Author name</label>
                </div>
                <div class="input-field">
                    <input type="text" name="surname" id="surname" required>
                    <label for="surname">Author surname</label>
                </div>
                <div class="input-field">
                    <input type="text" name="nationality" id="age" required>
                    <label for="nationality">Nationality</label>
                </div>
                <div class="input-field center">
                    <input class="btn" type="submit" value="Create Author">
                </div>

            </form>
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sync\_coding\backEnd\biblioteka-1\resources\views/authors/create.blade.php ENDPATH**/ ?>