<?php echo e($slot); ?>

<?php /**PATH D:\Sync\_coding\backEnd\biblioteka-1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>