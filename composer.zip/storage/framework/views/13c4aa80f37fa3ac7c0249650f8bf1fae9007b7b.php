<?php $__env->startSection('content'); ?>

<div class="container center" style="margin-top: 50px; margin-bottom: 50px;">
    <div>
        <a class="btn orange darken-1" href="<?php echo e(route('login')); ?>">Login</a>
    </div>
</div>
<div class="parallax-container">
    <div class="parallax">
    <img src="https://img-cdn.inc.com/image/upload/w_1920,h_1080,c_fill/images/panoramic/GettyImages-900301626_437925_t2i3bm.jpg" alt="stars" class="responsive-img">
    </div >

</div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sync\_coding\backEnd\biblioteka-1\resources\views/welcome.blade.php ENDPATH**/ ?>