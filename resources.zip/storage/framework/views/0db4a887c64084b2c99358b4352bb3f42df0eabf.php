<?php $__env->startSection('content'); ?>
<div class="container center">
    <?php if(session('status')): ?>
    <div>
        <h2><?php echo e(session('status')); ?></h2>
    </div>
    <?php endif; ?>

    <h4 class="grey-text text-darken-2">You are logged in!</h4>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sync\_coding\backEnd\biblioteka-1\resources\views/home.blade.php ENDPATH**/ ?>