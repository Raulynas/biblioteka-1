
<?php $__env->startSection('content'); ?>

<div class="container" style="padding-top: 30px;">
    <div class="row">
    </div>
    <div class="row">
        <div class="col s12 l7 offset-l1">
            <ul class="collection with-header">
                <li class="collection-header"><h4><?php echo e($author->name); ?> <?php echo e($author->surname); ?></h4></li>
                <?php $__currentLoopData = $author->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="collection-item italic-text"> <?php echo e($book->title); ?></li>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sync\_coding\backEnd\biblioteka-1\resources\views/authors/show.blade.php ENDPATH**/ ?>