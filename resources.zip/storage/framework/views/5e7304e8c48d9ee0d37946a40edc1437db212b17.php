
<?php $__env->startSection('content'); ?>


<div class="container" style="padding-top: 30px;">
    <div class="row">
        <div class="col s12 l8 offset-l1 center">
            <span class="indigo-text" style="font-style: italic"><?php echo e(session("msg")); ?></span>
        </div>
    </div>
    <div class="row">
        <div class="col s12 l8 offset-l1">

            <table class="highlight centered">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Surname</th>
                        <th>Nationality</th>
                        <th>Books</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($author["name"]); ?></td>
                        <td><?php echo e($author["surname"]); ?></td>
                        <td><?php echo e($author["nationality"]); ?></td>
                        <td><a href="<?php echo e(route("authors.show", $author)); ?>"><i class="material-icons teal-text text-lighten-1 ">book</i></a></td>
                        <td><a href="<?php echo e(route("authors.edit", $author)); ?>"><i class="material-icons green-text text-darken-1">edit</i></a></td>
                        <td>
                            <form id="destroy-form" action="<?php echo e(route('author.destroy', $author->id)); ?>" method="post">
                                <?php echo method_field("DELETE"); ?>
                                <?php echo csrf_field(); ?>
                                <button style="background-color: transparent; border: none; cursor: pointer;" class="tooltipped" data-position="right" data-tooltip="Delete Author">
                                    <i class="material-icons red-text">delete</i>
                                </button>
                            </form>
                            
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<!-- onclick="document.getElementById('destroy-form').submit()" -->
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sync\_coding\backEnd\biblioteka-1\resources\views/authors/index.blade.php ENDPATH**/ ?>