
<?php $__env->startSection('content'); ?>

<div class="container" style="padding-top: 30px;">
    <div class="row">
        <div class="col s12 l8 offset-l1 center">
            <span class="indigo-text" style="font-style: italic"><?php echo e(session("msg")); ?></span>
        </div>
    </div>
    <div class="row">
        <div class="col s12 l8 offset-l1">

            <table class="highlight centered">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Published</th>
                        <th>Pages</th>
                        <th>Cover</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($book["title"]); ?></td>
                    <td><a href="<?php echo e(route("authors.show", $book->author)); ?>"><?php echo e($book->author->name); ?> <?php echo e($book->author->surname); ?></a></td>
                    <td><?php echo e($book["publishDate"]); ?></td>
                    <td><?php echo e($book["pages"]); ?></td>
                    <td><?php echo e($book["coverType"]); ?></td>
                    <td><a href="<?php echo e(route("books.edit", $book)); ?>"><i class="material-icons green-text text-darken-1">edit</i></a></td>
                    <td>
                        <form id="destroy-form" action="<?php echo e(route('book.destroy', $book->id)); ?>" method="post">
                            <?php echo method_field("DELETE"); ?>
                            <?php echo csrf_field(); ?>
                            <button style="background-color: transparent; border: none" class="tooltipped" data-position="right" data-tooltip="Delete Book">
                                <i class="material-icons red-text">delete</i>
                            </button>
                        </form>
                    </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sync\_coding\backEnd\biblioteka-1\resources\views/books/index.blade.php ENDPATH**/ ?>